
agent_util sources:  

Just some shared generic source used by several of the demos.

